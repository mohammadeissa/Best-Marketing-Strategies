#ifndef ROI_ANALYSIS_H
#define ROI_ANALYSIS_H

#include "helpers.h"
#include <string>
#include <utility>

using namespace std;
/* pair is used to return category type and highest average
which is then used to formulate the table when the program ends.
Makes code more flexible and practical
https://www.geeksforgeeks.org/pair-in-cpp-stl/
*/
pair<string, double> findHighestAverageROIByCampaign(LinkedList<Array<string, 10>> dataset);
pair<string, double> findHighestAverageROIByCustomerSegment(LinkedList<Array<string, 10>> dataset);
pair<string, double> findHighestAverageROIByChannel(LinkedList<Array<string, 10>> dataset);
pair<string, double> findHighestAverageROIByTargetAudience(LinkedList<Array<string, 10>> dataset);

#endif
