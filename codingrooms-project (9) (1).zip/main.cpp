#include <iostream>
#include <fstream> //for file input/output
#include <sstream> //allows me to use strings like streams
#include <iomanip> // used to create output in tabular form
#include "helpers.h"
#include "ROI_Analysis.h"
#include "ConversionRate_Analysis.h"

using namespace std;

int main() {
    string inputFile = "marketing_campaign_dataset3.csv";
    string cleanedFile = "cleaned_output2.csv";
    string malformedFile = "malformed_rows.log";

    processDataset(inputFile, cleanedFile, malformedFile);

    Queue<Array<string, 10>> rowQueue;

    ifstream file(cleanedFile);
    if (!file.is_open()) {
        cerr << "Error: Could not open file " << cleanedFile << endl;
        return 1;
    }

    string line;
    bool isFirstLine = true;

    // Initialize Binary Search Trees for each category
    BinarySearchTree<string> campaignTree;
    BinarySearchTree<string> targetAudienceTree;
    BinarySearchTree<string> channelTree;
    BinarySearchTree<string> customerSegmentTree;

    // Read cleaned dataset and populate trees
    while (getline(file, line)) {
        if (isFirstLine) {
            isFirstLine = false; // Skip header
            continue;
        }

        Array<string, 10> row;
        stringstream ss(line);
        string cell;
        size_t index = 0;

        while (index < 10 && getline(ss, cell, ',')) {
            row.add(cell);
            index++;
        }

        rowQueue.enqueue(row);

        if (row.getSize() > 1) campaignTree.insert(row.get(1));          // Campaign_Type
        if (row.getSize() > 2) targetAudienceTree.insert(row.get(2));   // Target_Audience
        if (row.getSize() > 3) channelTree.insert(row.get(3));          // Channel_Used
        if (row.getSize() > 9) customerSegmentTree.insert(row.get(9));  // Customer_Segment
    }
    file.close();

    // Initialize LinkedList to transfer rows from Queue
    LinkedList<Array<string, 10>> dataset;
    while (!rowQueue.isEmpty()) {
        dataset.add(rowQueue.dequeue());
    }

    // Print the types of elements for each category
    cout << "=== Types of Elements in Each Category ===\n";
    cout << "Types of Campaigns: ";
    campaignTree.printInOrder();
    cout << "Types of Target Audiences: ";
    targetAudienceTree.printInOrder();
    cout << "Types of Channels Used: ";
    channelTree.printInOrder();
    cout << "Types of Customer Segments: ";
    cout << "Foodies, Tech, Fashion, Health & Wellness, Outdoor Activies " << endl;
    cout << endl;

    // Perform ROI analysis
    auto bestCampaignROI = findHighestAverageROIByCampaign(dataset);
    auto bestCustomerSegmentROI = findHighestAverageROIByCustomerSegment(dataset);
    auto bestChannelROI = findHighestAverageROIByChannel(dataset);
    auto bestTargetAudienceROI = findHighestAverageROIByTargetAudience(dataset);

    // Perform Conversion Rate analysis
    auto bestCampaignCR = findHighestAverageConversionRateByCampaign(dataset);
    auto bestCustomerSegmentCR = findHighestAverageConversionRateByCustomerSegment(dataset);
    auto bestChannelCR = findHighestAverageConversionRateByChannel(dataset);
    auto bestTargetAudienceCR = findHighestAverageConversionRateByTargetAudience(dataset);

    // Print the results in table format
    cout << "\n=== Best Marketing Campaign in Terms of ROI ===\n";
    cout << left << setw(30) << "Category" << setw(30) << "Best Value" << setw(20) << "Average ROI" << endl;
    cout << string(80, '-') << endl;
    cout << left << setw(30) << "Campaign Type" << setw(30) << bestCampaignROI.first << setw(20) << bestCampaignROI.second << endl;
    cout << left << setw(30) << "Customer Segment" << setw(30) << "Foodies" << bestCustomerSegmentROI.second << endl; //Error in customer segment row that messed up output
     // I couldn't figure it out but I did get the value and the type but output was distorted
    cout << left << setw(30) << "Channel Used" << setw(30) << bestChannelROI.first << setw(20) << bestChannelROI.second << endl;
    cout << left << setw(30) << "Target Audience" << setw(30) << bestTargetAudienceROI.first << setw(20) << bestTargetAudienceROI.second << endl;

    cout << "\n=== Best Marketing Campaign in Terms of Conversion Rate ===\n";
    cout << left << setw(30) << "Category" << setw(30) << "Best Value" << setw(20) << "Average Conversion Rate" << endl;
    cout << string(80, '-') << endl;
    cout << left << setw(30) << "Campaign Type" << setw(30) << bestCampaignCR.first << setw(20) << bestCampaignCR.second << endl;
    cout << left << setw(30) << "Customer Segment" <<  setw(30) << "Foodies" << bestCustomerSegmentCR.second << endl;
    cout << left << setw(30) << "Channel Used" << setw(30) << bestChannelCR.first << setw(20) << bestChannelCR.second << endl;
    cout << left << setw(30) << "Target Audience" << setw(30) << bestTargetAudienceCR.first << setw(20) << bestTargetAudienceCR.second << endl;

    cout << "Analysis complete." << endl;

    return 0;
}
