#include "ConversionRate_Analysis.h"
#include <iostream>
using namespace std;

pair<string, double> findHighestAverageConversionRateByCampaign(LinkedList<Array<string, 10>> dataset) {
    LinkedList<pair<string, pair<double, int>>> conversionRateList;

    Node<Array<string, 10>>* row = dataset.getHead();
    while (row) {
        string campaignType = row->data.get(1); // Campaign_Type
        double conversionRate = parseDouble(row->data.get(4)); // Conversion Rate

        Node<pair<string, pair<double, int>>>* current = conversionRateList.getHead();
        bool found = false;

        while (current) {
            if (current->data.first == campaignType) {
                current->data.second.first += conversionRate;
                current->data.second.second++;
                found = true;
                break;
            }
            current = current->next;
        }

        if (!found) {
            conversionRateList.add({campaignType, {conversionRate, 1}});
        }

        row = row->next;
    }

    string bestCampaign;
    double highestAverage = -1;

    Node<pair<string, pair<double, int>>>* current = conversionRateList.getHead();
    while (current) {
        double average = current->data.second.first / current->data.second.second;
        if (average > highestAverage) {
            highestAverage = average;
            bestCampaign = current->data.first;
        }
        current = current->next;
    }

    return {bestCampaign, highestAverage};
}

pair<string, double> findHighestAverageConversionRateByCustomerSegment(LinkedList<Array<string, 10>> dataset) {
    LinkedList<pair<string, pair<double, int>>> conversionRateList;

    Node<Array<string, 10>>* row = dataset.getHead();
    while (row) {
        string customerSegment = row->data.get(9); // Customer_Segment
        double conversionRate = parseDouble(row->data.get(4)); // Conversion Rate

        // Skip invalid rows
        if (customerSegment.empty() || conversionRate <= 0.0) {
            cout << "Skipped row due to invalid Customer Segment or Conversion Rate" << endl;
            row = row->next;
            continue;
        }

        Node<pair<string, pair<double, int>>>* current = conversionRateList.getHead();
        bool found = false;

        while (current) {
            if (current->data.first == customerSegment) {
                current->data.second.first += conversionRate;
                current->data.second.second++;
                found = true;
                break;
            }
            current = current->next;
        }

        if (!found) {
            conversionRateList.add({customerSegment, {conversionRate, 1}});
        }

        row = row->next;
    }

    string bestSegment;
    double highestAverage = -1;

    Node<pair<string, pair<double, int>>>* current = conversionRateList.getHead();
    while (current) {
        double average = current->data.second.first / current->data.second.second;
        if (average > highestAverage) {
            highestAverage = average;
            bestSegment = current->data.first;
        }
        current = current->next;
    }

    if (bestSegment.empty()) {
        cout << "No valid Customer Segment data found." << endl;
    }

    return {bestSegment, highestAverage};
}


pair<string, double> findHighestAverageConversionRateByChannel(LinkedList<Array<string, 10>> dataset) {
    LinkedList<pair<string, pair<double, int>>> conversionRateList;

    Node<Array<string, 10>>* row = dataset.getHead();
    while (row) {
        string channelUsed = row->data.get(3); // Channel_Used
        double conversionRate = parseDouble(row->data.get(4)); // Conversion Rate

        Node<pair<string, pair<double, int>>>* current = conversionRateList.getHead();
        bool found = false;

        while (current) {
            if (current->data.first == channelUsed) {
                current->data.second.first += conversionRate;
                current->data.second.second++;
                found = true;
                break;
            }
            current = current->next;
        }

        if (!found) {
            conversionRateList.add({channelUsed, {conversionRate, 1}});
        }

        row = row->next;
    }

    string bestChannel;
    double highestAverage = -1;

    Node<pair<string, pair<double, int>>>* current = conversionRateList.getHead();
    while (current) {
        double average = current->data.second.first / current->data.second.second;
        if (average > highestAverage) {
            highestAverage = average;
            bestChannel = current->data.first;
        }
        current = current->next;
    }

    return {bestChannel, highestAverage};
}

pair<string, double> findHighestAverageConversionRateByTargetAudience(LinkedList<Array<string, 10>> dataset) {
    LinkedList<pair<string, pair<double, int>>> conversionRateList;

    Node<Array<string, 10>>* row = dataset.getHead();
    while (row) {
        string targetAudience = row->data.get(2); // Target Audience
        double conversionRate = parseDouble(row->data.get(4)); // Conversion Rate

        Node<pair<string, pair<double, int>>>* current = conversionRateList.getHead();
        bool found = false;

        while (current) {
            if (current->data.first == targetAudience) {
                current->data.second.first += conversionRate;
                current->data.second.second++;
                found = true;
                break;
            }
            current = current->next;
        }

        if (!found) {
            conversionRateList.add({targetAudience, {conversionRate, 1}});
        }

        row = row->next;
    }

    string bestAudience;
    double highestAverage = -1;

    Node<pair<string, pair<double, int>>>* current = conversionRateList.getHead();
    while (current) {
        double average = current->data.second.first / current->data.second.second;
        if (average > highestAverage) {
            highestAverage = average;
            bestAudience = current->data.first;
        }
        current = current->next;
    }

    return {bestAudience, highestAverage};
}
