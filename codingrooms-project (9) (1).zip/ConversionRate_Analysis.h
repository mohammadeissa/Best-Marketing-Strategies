#ifndef CONVERSIONRATE_ANALYSIS_H
#define CONVERSIONRATE_ANALYSIS_H

#include "helpers.h"
#include <string>
#include <utility>

using namespace std;
/* pair is used to return category type and highest average
which is then used to formulate the table when the program ends.
Makes code more flexible and practical
https://www.geeksforgeeks.org/pair-in-cpp-stl/
*/

pair<string, double> findHighestAverageConversionRateByCampaign(LinkedList<Array<string, 10>> dataset);
pair<string, double> findHighestAverageConversionRateByCustomerSegment(LinkedList<Array<string, 10>> dataset);
pair<string, double> findHighestAverageConversionRateByChannel(LinkedList<Array<string, 10>> dataset);
pair<string, double> findHighestAverageConversionRateByTargetAudience(LinkedList<Array<string, 10>> dataset);

#endif
