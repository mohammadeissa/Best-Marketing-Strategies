#include "ROI_Analysis.h"
#include <iostream>
using namespace std;

pair<string, double> findHighestAverageROIByCampaign(LinkedList<Array<string, 10>> dataset) {
    LinkedList<pair<string, pair<double, int>>> roiList;

    Node<Array<string, 10>>* row = dataset.getHead(); // 10 rows in the csv file
    while (row) {
        string campaignType = row->data.get(1); // Campaign_Type
        double roi = parseDouble(row->data.get(5)); // ROI

        Node<pair<string, pair<double, int>>>* current = roiList.getHead();
        bool found = false;

        while (current) {
            if (current->data.first == campaignType) {
                current->data.second.first += roi;
                current->data.second.second++;
                found = true;
                break;
            }
            current = current->next;
        }

        if (!found) {
            roiList.add({campaignType, {roi, 1}});
        }

        row = row->next;
    }

    string bestCampaign;
    double highestAverage = -1;

    Node<pair<string, pair<double, int>>>* current = roiList.getHead();
    while (current) {
        double average = current->data.second.first / current->data.second.second;
        if (average > highestAverage) {
            highestAverage = average;
            bestCampaign = current->data.first;
        }
        current = current->next;
    }

    return {bestCampaign, highestAverage};
}

pair<string, double> findHighestAverageROIByCustomerSegment(LinkedList<Array<string, 10>> dataset) {
    LinkedList<pair<string, pair<double, int>>> roiList;

    Node<Array<string, 10>>* row = dataset.getHead();
    while (row) {
        string customerSegment = row->data.get(9); // Customer_Segment
        double roi = parseDouble(row->data.get(5)); // ROI

        // Skip invalid rows
       /* if (customerSegment.empty() || roi <= 0.0) {
            cout << "Skipped row due to invalid Customer Segment or ROI" << endl;
            row = row->next;
            continue;
        }
        USED FOR DEBUGGING*/

        Node<pair<string, pair<double, int>>>* current = roiList.getHead();
        bool found = false;

        while (current) {
            if (current->data.first == customerSegment) {
                current->data.second.first += roi;
                current->data.second.second++;
                found = true;
                break;
            }
            current = current->next;
        }

        if (!found) {
            roiList.add({customerSegment, {roi, 1}});
        }

        row = row->next;
    }

    string bestSegment;
    double highestAverage = -1;

    Node<pair<string, pair<double, int>>>* current = roiList.getHead();
    while (current) {
        double average = current->data.second.first / current->data.second.second;
        if (average > highestAverage) {
            highestAverage = average;
            bestSegment = current->data.first; // Assign correct segment
        }
        current = current->next;
    }

    /*if (bestSegment.empty()) {
        cout << "Warning: No valid Customer Segment data found." << endl;
    }
USED FOR DEBUGGING*/
    return {bestSegment, highestAverage};
}


pair<string, double> findHighestAverageROIByChannel(LinkedList<Array<string, 10>> dataset) {
    LinkedList<pair<string, pair<double, int>>> roiList;

    Node<Array<string, 10>>* row = dataset.getHead();
    while (row) {
        string channelUsed = row->data.get(3); // Channel_Used
        double roi = parseDouble(row->data.get(5)); // ROI

        Node<pair<string, pair<double, int>>>* current = roiList.getHead();
        bool found = false;

        while (current) {
            if (current->data.first == channelUsed) {
                current->data.second.first += roi;
                current->data.second.second++;
                found = true;
                break;
            }
            current = current->next;
        }

        if (!found) {
            roiList.add({channelUsed, {roi, 1}});
        }

        row = row->next;
    }

    string bestChannel;
    double highestAverage = -1;

    Node<pair<string, pair<double, int>>>* current = roiList.getHead();
    while (current) {
        double average = current->data.second.first / current->data.second.second;
        if (average > highestAverage) {
            highestAverage = average;
            bestChannel = current->data.first;
        }
        current = current->next;
    }

    return {bestChannel, highestAverage};
}

pair<string, double> findHighestAverageROIByTargetAudience(LinkedList<Array<string, 10>> dataset) {
    LinkedList<pair<string, pair<double, int>>> roiList;

    Node<Array<string, 10>>* row = dataset.getHead();
    while (row) {
        string targetAudience = row->data.get(2); // Target Audience
        double roi = parseDouble(row->data.get(5)); // ROI

        Node<pair<string, pair<double, int>>>* current = roiList.getHead();
        bool found = false;

        while (current) {
            if (current->data.first == targetAudience) {
                current->data.second.first += roi;
                current->data.second.second++;
                found = true;
                break;
            }
            current = current->next;
        }

        if (!found) {
            roiList.add({targetAudience, {roi, 1}});
        }

        row = row->next;
    }

    string bestAudience;
    double highestAverage = -1;

    Node<pair<string, pair<double, int>>>* current = roiList.getHead();
    while (current) {
        double average = current->data.second.first / current->data.second.second;
        if (average > highestAverage) {
            highestAverage = average;
            bestAudience = current->data.first;
        }
        current = current->next;
    }

    return {bestAudience, highestAverage};
}
