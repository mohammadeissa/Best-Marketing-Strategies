#include "helpers.h"
#include <sstream>
#include <fstream>
#include <iostream>
#include <algorithm> // Include this for count function

using namespace std;

// Function to parse a double from a string
double parseDouble(const string& value) {
    try {
        return stod(value);
    } catch (...) {
        return 0.0; // Return 0.0 if the value cannot be parsed
    }
}
//https://www.w3schools.com/cpp/cpp_exceptions.asp
// 

// Process the dataset and clean malformed rows
void processDataset(const string& inputFile, const string& cleanedFile, const string& malformedFile) {
    ifstream input(inputFile);
    ofstream cleanedOutput(cleanedFile);
    ofstream malformedOutput(malformedFile);

    if (!input.is_open() || !cleanedOutput.is_open() || !malformedOutput.is_open()) {
        cerr << "Error: Could not open one of the files." << endl;
        exit(1);
    }

    string line;
    bool isFirstLine = true;
    size_t expectedColumns = 0;

    while (getline(input, line)) {
        if (isFirstLine) {
            cleanedOutput << line << endl;
            expectedColumns = count(line.begin(), line.end(), ',') + 1;
            isFirstLine = false;
            continue;
        }

        size_t columns = count(line.begin(), line.end(), ',') + 1;
        if (columns == expectedColumns) {
            cleanedOutput << line << endl;
        } else {
            malformedOutput << line << endl;
        }
    }

    input.close();
    cleanedOutput.close();
    malformedOutput.close();
}
