#ifndef HELPERS_H
#define HELPERS_H

#include <string>
#include <vector>
#include <stdexcept>  // For runtime_error
#include <iostream>   // For cout and endl

using namespace std;

// Function to parse a double from a string
double parseDouble(const string& value);

// Helper functions
void processDataset(const string& inputFile, const string& cleanedFile, const string& malformedFile);

// LinkedList Node for storing rows
template <typename T>
class Node {
public:
    T data;
    Node* next;
    Node(T value) : data(value), next(nullptr) {}
};

// LinkedList
template <typename T>
class LinkedList {
private:
    Node<T>* head;
    Node<T>* tail;

public:
    LinkedList() : head(nullptr), tail(nullptr) {}

    void add(T value) {
        Node<T>* newNode = new Node<T>(value); // Wrap value in Node<T>
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    Node<T>* getHead() const {
        return head;
    }
};

// Fixed-size Array for storing columns within a row
template <typename T, size_t N>
class Array {
private:
    T data[N];
    size_t size;

public:
    Array() : size(0) {}

    void add(T value) {
        if (size < N) {
            data[size++] = value;
        }
    }

    T get(size_t index) const {
        return (index < size) ? data[index] : T();
    }

    size_t getSize() const {
        return size;
    }
};

// Binary Search Tree Node for category sorting
template <typename T>
class TreeNode {
public:
    T data;
    TreeNode* left;
    TreeNode* right;

    TreeNode(T value) : data(value), left(nullptr), right(nullptr) {}
};

template <typename T>
class BinarySearchTree {
private:
    TreeNode<T>* root;

    // Recursive helper function to insert a value into the tree
    TreeNode<T>* insert(TreeNode<T>* node, const T& value) {
        if (!node) return new TreeNode<T>(value); // Base case: Insert new node
        if (value < node->data)
            node->left = insert(node->left, value);
        else if (value > node->data)
            node->right = insert(node->right, value);
        return node;
    }

    // Recursive helper function for in-order traversal
    void inOrder(TreeNode<T>* node, vector<T>& result) const {
        if (!node) return;
        inOrder(node->left, result);
        result.push_back(node->data);
        inOrder(node->right, result);
    }

public:
    BinarySearchTree() : root(nullptr) {}

    // Public insert function
    void insert(const T& value) {
        root = insert(root, value);
    }

    // Print in-order traversal as a comma-separated list
    void printInOrder() const {
        vector<T> result;
        inOrder(root, result);

        for (size_t i = 0; i < result.size(); ++i) {
            cout << result[i];
            if (i < result.size() - 1) cout << ", "; // Add commas between entries
        }
        cout << endl;
    }
};

// Queue for processing rows
template <typename T>
class Queue {
private:
    struct Node {
        T data;
        Node* next;
        Node(T value) : data(value), next(nullptr) {}
    };

    Node* front;
    Node* rear;

public:
    Queue() : front(nullptr), rear(nullptr) {}

    void enqueue(T value) {
        Node* newNode = new Node(value);
        if (!rear) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
    }

    T dequeue() {
        if (!front) throw runtime_error("Queue is empty");
        Node* temp = front;
        T value = front->data;
        front = front->next;
        if (!front) rear = nullptr;
        delete temp;
        return value;
    }

    bool isEmpty() const {
        return !front;
    }
};


#endif
